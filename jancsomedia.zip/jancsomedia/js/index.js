/*****Active class  navbar*****/
$(document).ready(function() {
	var pathname = window.location.pathname;
	$('.navbar-list > li > a[href="'+pathname+'"]').parent().addClass('active');
});
/*****Grab list ******/
$(document).ready(function(){
	$('#left').sortable({
		connectWith:"#right",
		update:function(event, ui){
			$(this).children().each(function (index){
				
					$(this).attr('data-position', (index+1)).addClass('updatedLeft');
					$(this).attr('data-position', (index+1)).removeClass('updatedRight');

				
			});
		}
		
	});
	$('#right').sortable({
		connectWith:"#left",
		update:function(event, ui){
			$(this).children().each(function (index){
				
					$(this).attr('data-position', (index+1)).addClass('updatedRight');
					$(this).attr('data-position', (index+1)).removeClass('updatedLeft');
				
			});
		}
	});
});

$('#send').click(function(){
	saveNewPositionLeft();
	saveNewPositionRight();
});


function saveNewPositionLeft(){
	var positionsLeft = [];
	$('.updatedLeft').each(function () {
	   positionsLeft.push([$(this).attr('data-name'), $(this).attr('data-position')]);
	   $(this).removeClass('updatedLeft');
	});

	$.ajax({
		type: "POST",
		url: "../grab.php",
		dataType: "text",
	   data: {
		   positionsLeft: positionsLeft
	   }, success: function (response) {
			console.log(response);
	   },
	   	error: function(e){
			   console.log(e);
		   }
	});
}

function saveNewPositionRight(){
	var positionsRight = [];
	$('.updatedRight').each(function () {
	   positionsRight.push([$(this).attr('data-name'), $(this).attr('data-position')]);
	   $(this).removeClass('updatedRight');
	});

	$.ajax({
		type: "POST",
		url: "../grab.php",
		dataType: "text",
	   data: {
		   positionsRight: positionsRight
	   }, success: function (response) {
			console.log(response);
	   },
	   error: function(e){
		   console.log(e);
	   }
	});
}