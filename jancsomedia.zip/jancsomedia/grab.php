<?php

require 'includes/init.php';
Auth::requireLogin();
$conn = require 'includes/db.php';
$left = new LeftColumn();
$right = new RightColumn();
$left_items = LeftColumn::getAll($conn);
$right_items = RightColumn::getAll($conn);

if (isset($_POST['positionsLeft'])) {

    foreach($_POST['positionsLeft'] as $position) {
        $name = $position[0];
        $position = (int)$position[1];
        if($left->setLeftColumn($conn, $name, $position)){
            $message ='OK';
        }
       
     }   
    }


    if (isset($_POST['positionsRight'])) {

        foreach($_POST['positionsRight'] as $position) {
            $name = $position[0];
            $newPosition = (int)$position[1];
            if($right->setRightColumn($conn, $name, $newPosition)){
                $message ='OK';
            }
         } 
    }


?>
<?php require 'includes/header.php'; ?>
  
    <div class="outer">
        <div>
            <div class="container innert">
                <div class="row">
                    <div class="col-lg-6 left" id='left'>
                    <?php foreach($left_items as $left):?>
                        <p data-index=<?= $left['id'] ?> data-position=<?= $left['position'] ?> data-name=<?= $left['name'] ?>><?= $left['name'] ?></p>
                    <?php endforeach;?>    
                    </div>
                    <div class="col-lg-6 right" id="right">
                    <?php foreach($right_items as $right) :?>
                        <p data-index=<?= $right['id'] ?> data-position=<?= $right['position'] ?> data-name=<?= $right['name'] ?>><?= $right['name'] ?></p>
                    <?php endforeach;?> 
                    </div>
                </div>
            </div>
             <div class="btn-wrapper">
                    <button type="button" class="btn-general" id="send">Enter</button>
            </div>
        </div>
    </div>
    <!--/outer-->
    <div class="message text-center">
            <?php if(!empty($message)) :?>
                <p><?= "Your list has been succesful saved" ?></p>
            <?php endif;?> 
    </div>

<?php require 'includes/footer.php'; ?>   