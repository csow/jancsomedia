<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <nav>
                    <ul class="navbar-list-footer">
                        <li><a href="#">Condition of use</a>|</li>
                        <li><a href="#">Privacy statement</a>|</li>
                        <li><a href="#">Imprint</a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-lg-7">
                <div class="footer-text">
                    <p>This site is intended to provide information to an international audience outside the USA and the
                        UK</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"
    integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"
    integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU=" crossorigin="anonymous"></script>


<script src="js/index.js"></script>
</body>

</html>