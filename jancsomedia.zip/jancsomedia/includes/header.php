<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!--Fontawsome-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--Bootstrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <!--CSS-->
    <link rel="stylesheet" href="css/index.css">
</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-2 lock"><i class="fa fa-lock fa-4x"></i></div>
                <div class="col-lg-4 speaker">Speaker <br> portal</div>
                <div class="col-lg-4">
                    <ul class="navbar-list list-1">
                        <li class="navbar-list-font-light dropdown"> <a class="dropdown-toggle" href="#"
                                id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                English
                            </a>
                        </li>
                        <div class="vertical"></div>
                        <li class="navbar-list-font-light"><a href="#">Contact</a></li>
                        <li class="navbar-list-font-light"><a href="#">Sitemap</a></li>
                    </ul>
                    <hr>
                    <div class="row">
                        <div class="col-lg-12">
                            <ul class="navbar-list list-2">
                                <li class="navbar-list-font-bold"><a href="#"><i class="fa fa-folder"></i>My
                                        Collection</a></li>
                                <li class="navbar-list-font-bold"><a href="logout.php"><i
                                            class="fa fa-times-circle"></i>Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="logo ">logo</div>
                </div>
            </div>
            <!--End of first row-->
            <div class="row row-2">
                <div class="col-lg-9 vertical-2">
                    <nav>
                        <ul class="navbar-list list-3">
                            <li class="nav-item">
                                <a class="link" href="/"><i class="fa fa-home"></i></a>
                            </li>
                            <li class="nav-item">
                                <a class="link" href="/grab.php">MPAF</a>
                            </li>
                            <li class="nav-item">
                                <a class="link" href="#">Venious</a>
                            </li>
                            <li class="nav-item">
                                <a class="link" href="#">Acs</a>
                            </li>
                            <li class="nav-item">
                                <a class="link" href="#">Kivamoxoban studies</a>
                            </li>
                            <li class="nav-item">
                                <a class="link" href="#">Background information</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3"></div>
            </div>
        </div>
    </header>