<?php
/**
 * RightColumn
 * 
 * Items of the right column
 */

 class RightColumn
 {
    /**
     * Unique identifier
     * @var integer
     */
    public $id;

    /**
     * The name of the item
     * @var string
     */
    public $name;


    /**
     * The position of the element
     * @var integer
     */
    public $position;

    /**
     * Get all the items
     *
     * @param object $conn Connection to the database
     *
     * @return array An associative array of all the right cloumn records
     */
    public static function getAll($conn)
    {
        $sql = "SELECT * FROM right_column ORDER BY position";
            
        $results = $conn->query($sql);

        return $results->fetchAll(PDO::FETCH_ASSOC);
    }

    public function setRightColumn($conn, $name, $position)
    {
       $sql ="UPDATE right_column SET position = :position WHERE name = :name";

       $stmt = $conn->prepare($sql);

       $stmt->bindValue(':position', $position, PDO::PARAM_INT);

       $stmt->bindValue(':name', $name, PDO::PARAM_STR);

       $stmt->execute();

            $sql ="INSERT IGNORE INTO right_column (name, position) VALUES (:name, :position)";

            $stmt = $conn->prepare($sql);

            $stmt->bindValue(':name', $name, PDO::PARAM_STR);

            $stmt->bindValue(':position', $position, PDO::PARAM_INT);

           return  $stmt->execute();
       



           /* $sql = "DELETE FROM right_column WHERE name NOT IN (:name)";
           $stmt = $conn->prepare($sql);
           $stmt->bindValue(':name', $name, PDO::PARAM_STR);
           $stmt->execute();*/


         
       

         

           
        
    }
 }