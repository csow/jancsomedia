<?php
/**
 * LeftColumn
 * 
 * Items of the left column
 */

 class LeftColumn
 {
    /**
     * Unique identifier
     * @var integer
     */
    public $id;

    /**
     * The name of the item
     * @var string
     */
    public $name;


    /**
     * The position of the element
     * @var integer
     */
    public $position;

    /**
     * Get all the items
     *
     * @param object $conn Connection to the database
     *
     * @return array An associative array of all the left cloumn records
     */
    public static function getAll($conn)
    {
        $sql = "SELECT * FROM left_column ORDER BY position";

        $results = $conn->query($sql);

        return $results->fetchAll(PDO::FETCH_ASSOC);
    }

     public function setLeftColumn($conn, $name, $position)
     {
        $sql ="UPDATE left_column SET position = :position WHERE name = :name";

        $stmt = $conn->prepare($sql);

        $stmt->bindValue(':position', $position, PDO::PARAM_INT);

        $stmt->bindValue(':name', $name, PDO::PARAM_STR);

         $stmt->execute();

            $sql ="INSERT IGNORE INTO left_column (name, position) VALUES (:name, :position)";

            $stmt = $conn->prepare($sql);

            $stmt->bindValue(':name', $name, PDO::PARAM_STR);

            $stmt->bindValue(':position', $position, PDO::PARAM_INT);

           return $stmt->execute();
        

       

            /*$sql = "DELETE FROM left_column WHERE name NOT IN (:name)";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(':name', $name, PDO::PARAM_STR);
            $stmt->execute();*/
            
         
     }
 }