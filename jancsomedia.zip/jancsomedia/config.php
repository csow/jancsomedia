<?php

/**
 * Configuration settings
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'jancsomedia');
define('DB_USER', 'root');
define('DB_PASS', '');

define('SHOW_ERROR_DETAIL', true);