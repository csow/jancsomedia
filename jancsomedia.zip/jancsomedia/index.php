<?php

require 'includes/init.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $conn = require 'includes/db.php';

    if (User::authenticate($conn, $_POST['username'], $_POST['password'])) {
        
        Auth::login();

        Url::redirect('/grab.php');

    } else {
        
        $error = "error";

    }
}

?>
<?php require 'includes/header.php'; ?>

        <div class="parent">
            <form action="index.php" method="post" class="form-login">
                <div class="top-color"></div>
                <p>Please Sign in:</p>
                <div class="form-wrapper">
                    <label for="name">User name:</label>
                    <input type="text" name="username" id="name" class="form-input">
                </div>
                <div class="form-wrapper">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" class="form-input">
                </div>
                <div class="btn-wrapper">
                    <button type="submit" class="btn-general">Enter</button>
                </div>
            </form>
        </div>
        <div class="message text-center">
        <?php if (!empty($error)):?>
            <p><?= "Your username or password was incorrect" ?></p>
            <p><?= "Please try again" ?></p>
        <?php endif; ?>
        </div>

    <?php require 'includes/footer.php'; ?>   